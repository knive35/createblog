# Boilerplate code

### Getting Started

#### Familiar with Git?
Checkout this repo, install dependencies, then start the gulp process with the following:

```
> git clone https://agrawall.lokesh@gitlab.com/react-redux-bootcamp/boilerplate.git
> cd ReactReduxBootcamp
> npm install
> npm start
```
